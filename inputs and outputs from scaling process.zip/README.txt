These files are organized as in_states_(Temperature Value).txt and scaled_states_(Temperature Value).txt
They are formatted using a + char for a spin up (or down since it is symmetric with no B field) and a - char for the other.
Each line has the spins for each state ordered row-wise
There are 10 000 states in each file